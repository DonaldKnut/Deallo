import logo from "./dealo__.png";
import errorImg from "./scienerc-404-error-.png";
import heroImage from "./hero-image.png";

export default {
  logo,
  errorImg,
  heroImage,
};
