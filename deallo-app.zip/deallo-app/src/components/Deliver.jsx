import React from "react";
import Section from "./Section";
import imageMeeting from "@/images/meeting.jpg";
import List, { ListItem } from "./List";

const Deliver = () => {
  return (
    <Section title="Deliver" image={{ src: imageMeeting, shape: 1 }}>
      <div className="space-y-6 text-base text-white-600">
        <p>
          we recognize that every individual's career journey is unique, and we
          are committed to providing a platform that embraces this diversity.
          Our extensive job listings span various industries, ensuring that you
          can find the perfect fit for your skills and
          <strong className="font-semibold text-neutral-950"> Ambitions</strong>
          . This allows us to increase the budget a final time before launch.
        </p>
        <p>
          Despite largely using pre-built components, most of the{" "}
          <strong className="font-semibold text-neutral-950">progress</strong>{" "}
          Join a community of professionals and skilled workers. Network with
          peers, learn from industry experts, and stay informed about the latest
          trends in your field.
        </p>
        <p>
          we believe that every individual deserves the opportunity to thrive in
          their chosen profession.
          <strong className="font-semibold text-neutral-950">
            Join us today
          </strong>{" "}
          and embark on a journey to discover the perfect job opportunities that
          match your expertise and aspirations. Your next career move is just a
          <strong className="font-semibold text-white-950">click away!</strong>{" "}
        </p>
      </div>
      <h3 className="mt-12 font-display text-base font-semibold text-neutral-950">
        Included in this phase
      </h3>
      <List>
        <ListItem title="Connecting Professionals">
          Join a community of professionals and skilled workers. Network with
          peers, learn from industry experts, and stay informed about the latest
          trends in your field.
        </ListItem>
        <ListItem title="Tailored Recommendations">
          Our intelligent recommendation system suggests jobs that align with
          your qualifications and interests, saving you time and effort in your
          job search.
        </ListItem>
        <ListItem title="Diverse Opportunities">
          Our platform boasts an extensive and diverse selection of job
          listings. Whether you're a seasoned professional or just starting your
          career, you'll find opportunities that match your skills and
          preferences.
        </ListItem>
      </List>
    </Section>
  );
};

export default Deliver;
