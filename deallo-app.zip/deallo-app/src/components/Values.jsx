import React from "react";
import GridPattern from "./GridPattern";
import SectionIntro from "./SectionIntro";
import Container from "./Container";
import { GridList, GridListItem } from "./GridList";

const Values = () => {
  return (
    <div className="relative mt-24 pt-24 sm:mt-32 sm:pt-32 lg:mt-40 lg:pt-40">
      <div className="absolute inset-x-0 top-0 -z-10 h-[884px] overflow-hidden rounded-t-4xl bg-gradient-to-b from-neutral-50">
        <GridPattern
          className="absolute inset-0 h-full w-full fill-neutral-100 stroke-neutral-950/5 [mask-image:linear-gradient(to_bottom_left,white_40%,transparent_50%)]"
          yOffset={-270}
        />
      </div>
      <SectionIntro
        eyebrow="Our values"
        title="Balancing reliability and innovation"
      >
        <p className="text-green-350">
          We strive to stay at the forefront of emerging trends and
          technologies, while completely ignoring them and forking that old
          Rails project we feel comfortable using. We stand by our core values
          to justify that decision.
        </p>
      </SectionIntro>
      <Container className="mt-24">
        <GridList>
          <GridListItem title="Skill Enhancement">
            Continuous learning is key to success. We provide resources and
            courses to help you enhance your skills, regardless of your
            profession. Stay competitive and stay ahead in your career journey.
          </GridListItem>
          <GridListItem title="Safety and Security">
            We prioritize safety in all professions. From construction sites to
            corporate offices, we ensure that job listings adhere to the highest
            safety standards. Your well-being is our priority.
          </GridListItem>
          <GridListItem title="Fostering Inclusivity">
            We're committed to fostering inclusivity in the workforce by
            providing a level playing field for professionals across diverse
            industries. We recognize that talent is universal, and it knows no
            boundaries. Whether you're a highly skilled software engineer, a
            dedicated construction worker, or an expert in any field, we are
            here to support your journey.
          </GridListItem>
          <GridListItem title="Community Building">
            Join our vibrant community of professionals. Share your experiences,
            seek advice, and build meaningful connections. Networking
            opportunities abound, allowing you to expand your horizons and gain
            insights from diverse perspectives.
          </GridListItem>
          <GridListItem title="Career Advancement">
            Provide tools and resources for career advancement. Offer mentorship
            programs, career coaching, and guidance to help workers navigate
            their career paths effectively.
          </GridListItem>
          <GridListItem title="Inclusivity and Diversity">
            Promote diversity and inclusivity in the workplace. Encourage
            employers to embrace diversity in their workforce and create
            environments where every individual's unique background and skills
            are valued.
          </GridListItem>
        </GridList>
      </Container>
    </div>
  );
};

export default Values;
