import React from "react";
import Section from "./Section";
import imageLaptop from "@/images/laptop.jpg";
import Blockquote from "./Blockquote";

const Build = () => {
  return (
    <Section title="Build" image={{ src: imageLaptop, shape: 2 }}>
      <div className="space-y-6 text-base text-white-600">
        <p>
          Explore a vast array of job listings tailored to white and blue-collar
          professions. Whether you're an experienced welder, electrician, truck
          driver, banker, Software Engineer, Pilot, Teacher or have other
          skills, you'll find opportunities that match your expertise.
        </p>
        <p>
          Our mission is to break down the barriers that traditionally separate
          white-collar and blue-collar workers. We believe that every individual
          deserves access to fulfilling job opportunities, regardless of their
          profession. Our platform is designed to empower workers from all walks
          of life.
        </p>
        <p>
          Continuous learning is key to success. We provide resources and
          courses to help you enhance your skills, regardless of your
          profession. Stay competitive and stay ahead in your career journey.
        </p>
      </div>
      <Blockquote
        author={{ name: "Debra Fiscal", role: "CEO of Family Fund" }}
        className="mt-12"
      >
        At Deallo, their mission is clear: to bridge the gap between skilled
        white and blue-collar workers and employers seeking their valuable
        expertise. they mostly believe that every worker deserves access to
        fulfilling job opportunities that match their skills and aspirations.
        Our platform is designed to empower workers and employers alike.
      </Blockquote>
    </Section>
  );
};

export default Build;
