import React from "react";
import Section from "./Section";
import imageWhiteboard from "@/images/whiteboard.jpg";
import { TagList, TagListItem } from "./TagList";

const Discover = () => {
  return (
    <Section title="Discover" image={{ src: imageWhiteboard, shape: 1 }}>
      <div className="space-y-6 text-base text-white-600">
        <p>
          We work closely with our clients to understand their{" "}
          <strong className="font-semibold text-neutral-950">needs</strong> and
          goals, embedding ourselves in their every day operations to understand
          what makes their business tick.
        </p>
        <p>
          Our intelligent recommendation system suggests jobs that align with
          your qualifications and interests, saving you time and effort in your
          job search.
          <strong className="font-semibold text-neutral-950">
            {" "}
            Mentorship
          </strong>
          Programs - Mentorship is a powerful way for individuals to gain
          insights, knowledge, and guidance from seasoned professionals in their
          field. We facilitate mentorship programs that connect experienced
          mentors with aspiring professionals
        </p>
        {/* <p>
          Once the full audit is complete, we report back with a comprehensive
          <strong className="font-semibold text-neutral-950">plan</strong> and,
          more importantly, a budget.
        </p> */}
      </div>
      <h3 className="mt-12 font-display text-base font-semibold text-neutral-950">
        Included in this phase
      </h3>
      <TagList className="mt-4">
        <TagListItem>Matching</TagListItem>
        <TagListItem>Structured Sessions</TagListItem>
        <TagListItem>Skill Development</TagListItem>
        <TagListItem>Online Courses</TagListItem>
        <TagListItem>Career Coaching</TagListItem>
        <TagListItem>Resume and Interview Preparation</TagListItem>
      </TagList>
    </Section>
  );
};

export default Discover;
